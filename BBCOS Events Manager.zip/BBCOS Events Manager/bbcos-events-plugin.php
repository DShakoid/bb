<?php
/*
Plugin Name: Менеджер Подій BBCOS
Plugin URI:  http://example.com
Description: Керування та відображення подій на вашому сайті WordPress.
Version:     1.0
Author:      Shako
Author URI:  http://example.com
*/

define('BBCOS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('BBCOS_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once BBCOS_PLUGIN_DIR . 'includes/custom-post-types.php';
require_once BBCOS_PLUGIN_DIR . 'includes/enqueue-scripts.php';
require_once BBCOS_PLUGIN_DIR . 'includes/metaboxes.php';

register_activation_hook(__FILE__, 'bbcos_activate_plugin');
function bbcos_activate_plugin() {
    bbcos_register_event_post_type();
    flush_rewrite_rules();
}

register_deactivation_hook(__FILE__, 'bbcos_deactivate_plugin');
function bbcos_deactivate_plugin() {
    flush_rewrite_rules();
}

register_uninstall_hook(__FILE__, 'bbcos_uninstall_plugin');
function bbcos_uninstall_plugin() {
    $events = get_posts(array(
        'post_type' => 'shako_event',
        'numberposts' => -1,
        'fields' => 'ids'
    ));

    if ($events) {
        foreach ($events as $event_id) {
            wp_delete_post($event_id, true);
        }
    }
}

// Function to load Elementor widgets
function bbcos_register_elementor_widgets($widgets_manager) {
    if (did_action('elementor/loaded')) {
        require_once BBCOS_PLUGIN_DIR . 'includes/elementor-widgets.php';
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Shako_Event_Speaker_Widget() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Shako_Event_Location_Widget() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Shako_Event_City_Widget() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Shako_Event_Type_Widget() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Shako_Event_Format_Widget() );
    }
}

add_action('elementor/widgets/widgets_registered', 'bbcos_register_elementor_widgets');
