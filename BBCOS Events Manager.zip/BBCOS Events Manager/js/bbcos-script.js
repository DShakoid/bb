// JavaScript для интерактивности мероприятий
document.addEventListener('DOMContentLoaded', function() {
    // Весь код для интерактивности мероприятий
    console.log('BBCOS Events Plugin JS Loaded');
});
