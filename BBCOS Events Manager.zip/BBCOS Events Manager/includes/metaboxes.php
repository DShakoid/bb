<?php
function shako_add_event_metabox() {
    add_meta_box(
        'shako_event_details',
        __('Деталі Події', 'shako'),
        'shako_event_details_metabox_callback',
        'shako_event',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'shako_add_event_metabox');

function shako_event_details_metabox_callback($post) {
    // Добавление nonce-поля для безопасности
    wp_nonce_field('shako_event_details_action', 'shako_event_details_nonce');

    // Получение сохраненных значений
    $start_date = get_post_meta($post->ID, 'shako_event_start_date', true);
    $start_hour = get_post_meta($post->ID, 'shako_event_start_hour', true);
    $end_date = get_post_meta($post->ID, 'shako_event_end_date', true);
    $end_hour = get_post_meta($post->ID, 'shako_event_end_hour', true);
    $location = get_post_meta($post->ID, 'shako_event_location', true);
    $speaker = get_post_meta($post->ID, 'shako_event_speaker', true);
    $city = get_post_meta($post->ID, 'shako_event_city', true);
    $type = get_post_meta($post->ID, 'shako_event_type', true);
    $format = get_post_meta($post->ID, 'shako_event_format', true);

    // Поля введення
    echo '<p><label for="shako_event_speaker">' . __('Спікер', 'shako') . '</label>';
    echo '<input type="text" id="shako_event_speaker" name="shako_event_speaker" value="' . esc_attr($speaker) . '" class="widefat"></p>';

    echo '<p><label for="shako_event_location">' . __('Локація', 'shako') . '</label>';
    echo '<input type="text" id="shako_event_location" name="shako_event_location" value="' . esc_attr($location) . '" class="widefat"></p>';

    echo '<p><label for="shako_event_city">' . __('Місто проведення', 'shako') . '</label>';
    echo '<input type="text" id="shako_event_city" name="shako_event_city" value="' . esc_attr($city) . '" class="widefat"></p>';

    echo '<p><label for="shako_event_start_date">' . __('Час початку: Оберіть дату', 'shako') . '</label>';
    echo '<input type="date" id="shako_event_start_date" name="shako_event_start_date" value="' . esc_attr($start_date) . '" class="datepicker">';
    echo '<label for="shako_event_start_hour" style="margin-left: 10px;">' . __('Оберіть час', 'shako') . '</label>';
    echo '<input type="time" id="shako_event_start_hour" name="shako_event_start_hour" value="' . esc_attr($start_hour) . '" class="timepicker"></p>';

    echo '<p><label for="shako_event_end_date">' . __('Час закінчення: Оберіть дату', 'shako') . '</label>';
    echo '<input type="date" id="shako_event_end_date" name="shako_event_end_date" value="' . esc_attr($end_date) . '" class="datepicker">';
    echo '<label for="shako_event_end_hour" style="margin-left: 10px;">' . __('Оберіть час', 'shako') . '</label>';
    echo '<input type="time" id="shako_event_end_hour" name="shako_event_end_hour" value="' . esc_attr($end_hour) . '" class="timepicker"></p>';

    echo '<p><label for="shako_event_type">' . __('Тип події', 'shako') . '</label>';
    echo '<select id="shako_event_type" name="shako_event_type" class="widefat">';
    $types = ['Семінар', 'Вебінар', 'Майстер-клас', 'Навчання', 'Презентація продукту'];
    foreach ($types as $option) {
        echo '<option value="' . esc_attr($option) . '" ' . selected($type, $option, false) . '>' . esc_html($option) . '</option>';
    }
    echo '</select></p>';

    echo '<p><label for="shako_event_format">' . __('Формат події', 'shako') . '</label>';
    echo '<select id="shako_event_format" name="shako_event_format" class="widefat">';
    $formats = ['Онлайн', 'Оффлайн'];
    foreach ($formats as $option) {
        echo '<option value="' . esc_attr($option) . '" ' . selected($format, $option, false) . '>' . esc_html($option) . '</option>';
    }
    echo '</select></p>';
}

function shako_save_event_details($post_id) {
    // Проверка nonce для безопасности
    if (!isset($_POST['shako_event_details_nonce']) || !wp_verify_nonce($_POST['shako_event_details_nonce'], 'shako_event_details_action')) {
        return;
    }

    // Дополнительные проверки прав пользователя
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Сохранение данных из полей
    if (isset($_POST['shako_event_start_date'])) {
        $start_time = sanitize_text_field($_POST['shako_event_start_date']) . ' ' . sanitize_text_field($_POST['shako_event_start_hour']) . ':00';
        update_post_meta($post_id, 'shako_event_start_time', $start_time);
    }

    if (isset($_POST['shako_event_end_date'])) {
        $end_time = sanitize_text_field($_POST['shako_event_end_date']) . ' ' . sanitize_text_field($_POST['shako_event_end_hour']) . ':00';
        update_post_meta($post_id, 'shako_event_end_time', $end_time);
    }

    // Сохранение других метаданных
    update_post_meta($post_id, 'shako_event_speaker', sanitize_text_field($_POST['shako_event_speaker']));
    update_post_meta($post_id, 'shako_event_location', sanitize_text_field($_POST['shako_event_location']));
    update_post_meta($post_id, 'shako_event_city', sanitize_text_field($_POST['shako_event_city']));
    update_post_meta($post_id, 'shako_event_type', sanitize_text_field($_POST['shako_event_type']));
    update_post_meta($post_id, 'shako_event_format', sanitize_text_field($_POST['shako_event_format']));
}

add_action('save_post', 'shako_save_event_details');