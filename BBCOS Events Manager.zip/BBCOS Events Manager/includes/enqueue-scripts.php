<?php
function shako_enqueue_scripts() {
    wp_enqueue_style('shako-style', BBCOS_PLUGIN_URL . 'css/shako-style.css');
    
    // Подключение стилей для jQuery UI Datepicker
    wp_enqueue_style('jquery-ui-datepicker', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
    
    // Подключение jQuery UI
    wp_enqueue_script('jquery-ui-datepicker');
    wp_enqueue_script('jquery-ui-core');
    wp_enqueue_script('jquery-ui-widget');
    wp_enqueue_script('jquery-ui-position');
    wp_enqueue_script('jquery-ui-menu');
    wp_enqueue_script('jquery-ui-autocomplete');

    // Подключение объединенного скрипта для DatePicker и TimePicker
    wp_enqueue_script('jquery-timepicker', BBCOS_PLUGIN_URL . 'js/jquery-timepicker.js', array('jquery', 'jquery-ui-datepicker'), null, true);
}

add_action('wp_enqueue_scripts', 'shako_enqueue_scripts');
?>
