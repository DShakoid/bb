<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Добавление новой категории для виджетов Shako
function shako_add_elementor_widget_categories($elements_manager) {
    $elements_manager->add_category(
        'shako-widgets',
        [
            'title' => __('Shako Widgets', 'shako'),
            'icon' => 'fa fa-plug',
        ]
    );
}
add_action('elementor/elements/categories_registered', 'shako_add_elementor_widget_categories');

// Определение виджета "Shako_Event_Speaker_Widget"
class Shako_Event_Speaker_Widget extends \Elementor\Widget_Base {
    public function get_name() {
        return 'shako_event_speaker';
    }

    public function get_title() {
        return __('Спікер Мероприятия', 'shako');
    }

    public function get_icon() {
        return 'fa fa-user';
    }

    public function get_categories() {
        return ['shako-widgets'];
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Налаштування', 'shako'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'speaker_prefix',
            [
                'label' => __('Префикс', 'shako'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Спікер:', 'shako'),
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $post_id = get_the_ID();
        $speaker = get_post_meta($post_id, 'shako_event_speaker', true);

        if (!$speaker) {
            return;
        }

        $prefix = $this->get_settings('speaker_prefix');
        echo '<div class="shako-event-speaker">';
        echo esc_html($prefix) . ' ' . esc_html($speaker);
        echo '</div>';
    }

    protected function _content_template() {
        ?>
        <#
        var speaker = settings.speaker_prefix + ' ' + settings.speaker;
        if (!speaker) {
            return;
        }
        #>
        <div class="shako-event-speaker">
            {{{ speaker }}}
        </div>
        <?php
    }
}

// Определение виджета "Shako_Event_Location_Widget"
class Shako_Event_Location_Widget extends \Elementor\Widget_Base {
    public function get_name() {
        return 'shako_event_location';
    }

    public function get_title() {
        return __('Локація Мероприятия', 'shako');
    }

    public function get_icon() {
        return 'fa fa-map-marker';
    }

    public function get_categories() {
        return ['shako-widgets'];
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Налаштування', 'shako'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'location_prefix',
            [
                'label' => __('Префикс', 'shako'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Локація:', 'shako'),
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $post_id = get_the_ID();
        $location = get_post_meta($post_id, 'shako_event_location', true);

        if (!$location) {
            return;
        }

        $prefix = $this->get_settings('location_prefix');
        echo '<div class="shako-event-location">';
        echo esc_html($prefix) . ' ' . esc_html($location);
        echo '</div>';
    }

    protected function _content_template() {
        ?>
        <#
        var location = settings.location_prefix + ' ' + settings.location;
        if (!location) {
            return;
        }
        #>
        <div class="shako-event-location">
            {{{ location }}}
        </div>
        <?php
    }
}

// Определение виджета "Shako_Event_City_Widget"
class Shako_Event_City_Widget extends \Elementor\Widget_Base {
    public function get_name() {
        return 'shako_event_city';
    }

    public function get_title() {
        return __('Місто Мероприятия', 'shako');
    }

    public function get_icon() {
        return 'fa fa-building';
    }

    public function get_categories() {
        return ['shako-widgets'];
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Налаштування', 'shako'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'city_prefix',
            [
                'label' => __('Префикс', 'shako'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Місто:', 'shako'),
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $post_id = get_the_ID();
        $city = get_post_meta($post_id, 'shako_event_city', true);

        if (!$city) {
            return;
        }

        $prefix = $this->get_settings('city_prefix');
        echo '<div class="shako-event-city">';
        echo esc_html($prefix) . ' ' . esc_html($city);
        echo '</div>';
    }

    protected function _content_template() {
        ?>
        <#
        var city = settings.city_prefix + ' ' + settings.city;
        if (!city) {
            return;
        }
        #>
        <div class="shako-event-city">
            {{{ city }}}
        </div>
        <?php
    }
}

// Определение виджета "Shako_Event_Type_Widget"
class Shako_Event_Type_Widget extends \Elementor\Widget_Base {
    public function get_name() {
        return 'shako_event_type';
    }

    public function get_title() {
        return __('Тип Мероприятия', 'shako');
    }

    public function get_icon() {
        return 'fa fa-list';
    }

    public function get_categories() {
        return ['shako-widgets'];
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Налаштування', 'shako'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'type_prefix',
            [
                'label' => __('Префикс', 'shako'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Тип:', 'shako'),
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $post_id = get_the_ID();
        $type = get_post_meta($post_id, 'shako_event_type', true);

        if (!$type) {
            return;
        }

        $prefix = $this->get_settings('type_prefix');
        echo '<div class="shako-event-type">';
        echo esc_html($prefix) . ' ' . esc_html($type);
        echo '</div>';
    }

    protected function _content_template() {
        ?>
        <#
        var type = settings.type_prefix + ' ' + settings.type;
        if (!type) {
            return;
        }
        #>
        <div class="shako-event-type">
            {{{ type }}}
        </div>
        <?php
    }
}

// Определение виджета "Shako_Event_Format_Widget"
class Shako_Event_Format_Widget extends \Elementor\Widget_Base {
    public function get_name() {
        return 'shako_event_format';
    }

    public function get_title() {
        return __('Формат Мероприятия', 'shako');
    }

    public function get_icon() {
        return 'fa fa-file-text';
    }

    public function get_categories() {
        return ['shako-widgets'];
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Налаштування', 'shako'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'format_prefix',
            [
                'label' => __('Префикс', 'shako'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Формат:', 'shako'),
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $post_id = get_the_ID();
        $format = get_post_meta($post_id, 'shako_event_format', true);

        if (!$format) {
            return;
        }

        $prefix = $this->get_settings('format_prefix');
        echo '<div class="shako-event-format">';
        echo esc_html($prefix) . ' ' . esc_html($format);
        echo '</div>';
    }

    protected function _content_template() {
        ?>
        <#
        var format = settings.format_prefix + ' ' + settings.format;
        if (!format) {
            return;
        }
        #>
        <div class="shako-event-format">
            {{{ format }}}
        </div>
        <?php
    }
}

// Регистрация всех виджетов в категории 'shako-widgets'
function shako_register_elementor_widgets() {
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Shako_Event_Speaker_Widget() );
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Shako_Event_Location_Widget() );
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Shako_Event_City_Widget() );
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Shako_Event_Type_Widget() );
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Shako_Event_Format_Widget() );
}
add_action('elementor/widgets/widgets_registered', 'shako_register_elementor_widgets');
