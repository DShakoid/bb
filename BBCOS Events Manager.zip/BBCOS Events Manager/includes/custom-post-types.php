<?php
function shako_register_event_post_type() {
    $labels = array(
        'name'                  => _x('Події Shako', 'Post type general name', 'shako'),
        'singular_name'         => _x('Подія Shako', 'Post type singular name', 'shako'),
        'menu_name'             => _x('Події Shako', 'Admin Menu text', 'shako'),
        'name_admin_bar'        => _x('Подія Shako', 'Add New on Toolbar', 'shako'),
        'add_new'               => __('Додати Нову', 'shako'),
        'add_new_item'          => __('Додати Нову Подію', 'shako'),
        'new_item'              => __('Нова Подія', 'shako'),
        'edit_item'             => __('Редагувати Подію', 'shako'),
        'view_item'             => __('Переглянути Подію', 'shako'),
        'all_items'             => __('Всі Події', 'shako'),
        'search_items'          => __('Шукати Події', 'shako'),
        'parent_item_colon'     => __('Батьківські Події:', 'shako'),
        'not_found'             => __('Подій не знайдено.', 'shako'),
        'not_found_in_trash'    => __('Подій у кошику не знайдено.', 'shako')
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'shako-events'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
        'show_in_rest'       => true
    );

    register_post_type('shako_event', $args);
}
add_action('init', 'shako_register_event_post_type');
?>
