<?php
// Підключаємо стандартний заголовок сайту
get_header(); 
?>

<div class="shako-event-content">
    <?php
    while (have_posts()) : the_post();
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
                <h1 class="entry-title"><?php the_title(); ?></h1>
            </header>

            <div class="entry-content">
                <?php
                // Виведення змісту події
                the_content();

                // Приклад виведення кастомних полів, якщо вони є
                $speaker = get_post_meta(get_the_ID(), 'shako_event_speaker', true);
                if ($speaker) {
                    echo '<p><strong>Спікер:</strong> ' . esc_html($speaker) . '</p>';
                }

                // Повторіть для інших кастомних полів
                ?>
            </div>
        </article>
    <?php
    endwhile; 
    ?>
</div>

<?php
// Підключаємо стандартний футер сайту
get_footer(); 
?>
